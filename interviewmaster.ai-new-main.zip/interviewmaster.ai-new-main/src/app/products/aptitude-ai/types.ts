export interface ProgressData {
  questionsSolved: number;
  questionsChange: string;
  accuracyRate: number;
  accuracyChange: string;
  avgTime: string;
  timeChange: string;
}

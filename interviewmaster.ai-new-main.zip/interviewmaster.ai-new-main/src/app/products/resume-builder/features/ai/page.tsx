import React from 'react';

const Page: React.FC = () => {
  return (
    <div>
      <h1>Resume Builder</h1>
      {/* Add your content here */}
    </div>
  );
};

export default Page;
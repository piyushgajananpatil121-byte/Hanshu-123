# Server Credentials and Details

## VPS Information
- IP Address: 194.164.150.148
- Provider: Hostinger
- Server Location: Mumbai, India

## Domain Information
- Domain Name: interviewmaster.site
- Registrar: Hostinger

## SSH Access
```bash
ssh root@194.164.150.148
```

## Important URLs
- Main Site: https://interviewmaster.site
- WWW Site: https://www.interviewmaster.site

## Repository
- GitHub Repository: https://github.com/humeshdeshmukh/interviewmaster.ai-new.git

## Important Note
Keep this file secure and do not commit it to version control.


## github token 


## ssh key 
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHQ0LBsrpjqqENehCJDDvnmutJUh+HY86WRNLgfuzPzi humeshdeshmukh@Gmail.com
